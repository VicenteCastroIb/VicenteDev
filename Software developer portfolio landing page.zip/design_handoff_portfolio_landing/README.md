# Handoff: Portfolio Landing Page — Vicente Castro

## Overview
Single-page portfolio/landing site for Vicente Castro, a full-stack developer. Dark, corporate-tech aesthetic with a fixed header, full-bleed photo hero, hexagonal project cards, an about/quote section, a combined skills+certifications section, and a footer with contact/site links.

## About the Design Files
The file in this bundle (`portfolio-landing.html`) is a **design reference built in HTML** — it shows exact layout, colors, typography, copy and interactions, but it is NOT production code to paste into an app as-is. Recreate this UI pixel-perfectly in the target codebase's stack (React, Vue, plain HTML/CSS, etc. — pick the most appropriate if none exists yet), using the codebase's existing component patterns, image pipeline, and routing.

## Fidelity
**High-fidelity.** Every color, font size, spacing value, and copy string below is final. Implement pixel-perfectly.

## Global styles
- Fonts: Google Fonts `Sora` (weights 300, 500, 600, 700, 800) for headings/labels, `Inter` (400, 500, 600) for body text. Loaded via `<link>`, not self-hosted.
- Base background: `#0a1520`. Base text color: `#eaf2f5`.
- Accent color (cyan): `#4dd0e1` (tweakable; alternates used elsewhere in the palette: `#38bdf8`, `#22d3ee`, `#5eead4`).
- All link elements: `color:inherit; text-decoration:none`, with a per-context hover color of `var(--accent)`.
- Card/section corner treatment is a CSS custom property so it can flip between two states: hexagon (`clip-path: polygon(25% 0%,75% 0%,100% 50%,75% 100%,25% 100%,0% 50%)`, `border-radius:0`) or rounded (`clip-path:none`, `border-radius:18px`). Default = hexagon.
- Keyframes: `bounce` (scroll-cue chevron, translateY 0→8px→0, 2.2s ease-in-out infinite), `glow` (unused blob opacity pulse, kept for reference only).

## Screens / Sections
This is one continuous scrolling page (anchor-linked), not multiple screens.

### 1. Header (fixed)
- **Purpose**: Persistent nav + language toggle.
- **Layout**: `position:fixed`, full width, height 76px, flex row, `justify-content:space-between`, horizontal padding `clamp(20px,4vw,56px)`.
- **Style**: background `rgba(10,21,32,.82)`, `backdrop-filter: blur(10px)`, bottom border `1px solid rgba(255,255,255,.08)`. z-index 50.
- **Components**:
  - Logo text "VICENTE CASTRO" — Sora 600, 14px, letter-spacing 2px, color `rgba(234,242,245,.85)`.
  - Nav links (center, flex gap `clamp(20px,3vw,44px)`): PROYECTOS (→#projects), SOBRE MI (→#about), SKILLS (→#skills), CONTACT (→#contact). Each: 12px/600/letter-spacing 2px, color `rgba(234,242,245,.75)`, 1px transparent bottom border that turns `var(--accent)` on hover along with text color.
  - Right cluster: two circular language toggles "ESP" / "ENG", 32×32px circles, 1px border `rgba(255,255,255,.2)`, 10px/700 text, hover border+text → accent.

### 2. Hero
- **Purpose**: Primary headline + CTA.
- **Layout**: `min-height:80vh`, flex column, centered content, text-center, padding `150px clamp(20px,6vw,50px) 90px`.
- **Background**: full-bleed photo (`hero-photo.jpg` — dark mountain/night landscape) `center/cover`, with a dark gradient scrim on top: `linear-gradient(180deg, rgba(10,21,32,.5) 0%, rgba(10,21,32,.72) 55%, rgba(0,0,0,.92) 100%)` for text legibility.
- **Content stack** (max-width 840px, gap 22px):
  - H1, two lines, Sora, line-height 1.05:
    - "SOLUCIONES" — weight 300, `clamp(34px,6vw,64px)`, letter-spacing 1px, color `#eaf2f5`.
    - "DIGITALES" — weight 800, `clamp(44px,8vw,84px)`, letter-spacing 1px, color `#ffffff`.
  - Paragraph (max-width 560px, 16px/1.7, color `rgba(255,255,255,.7)`): "Desarrollador full-stack. Diseño y construyo productos web robustos, de un backend escalable a la interfaz pulida, con foco en rendimiento y detalle."
  - CTA button "LEARN MORE" — 12px/700, letter-spacing 3px, padding 16px 40px, 1px border `rgba(255,255,255,.35)`, transparent bg, `border-radius:2px`; on hover bg → accent, text → `#08141d`. Clicking scrolls smoothly to `#projects` (offset -70px for the fixed header).
  - Scroll cue: 14×14px chevron (two rotated borders forming a "v"), color `rgba(234,242,245,.6)`, `bounce` animation 2.2s infinite; same click-to-scroll behavior.

### 3. Projects ("Proyectos & Capacidades") — id="projects"
- **Layout**: padding `110px clamp(20px,6vw,56px) 130px`, background 3-stop vertical gradient `linear-gradient(180deg, #000000, #17273C, #000409)`, flex column centered.
- **Section header**: eyebrow "EXPLORA MI TRABAJO" (12px/700, letter-spacing 4px, color accent) + H2 "Proyectos & Capacidades" (Sora 700, `clamp(26px,4vw,38px)`, white).
- **Cards row**: 3 hexagon cards, 252×222px each, `gap:26px`, wrapped in a `max-width:900px` flex row.
  - Each card is a stack of absolutely-positioned layers clipped to the hex shape:
    1. Background photo (`center top / cover`) — real project screenshot.
    2. Linear gradient scrim: `linear-gradient(180deg, rgba(10,21,32,.1) 0%, rgba(10,21,32,.8) 100%)`.
    3. Radial vignette: `radial-gradient(ellipse at center, transparent 52%, rgba(6,13,20,.65) 100%)` — darkens the hex edges.
    4. 1px inset border `rgba(255,255,255,.12)`, turning `var(--accent)` on hover.
    5. Foreground content, bottom-aligned, padding 22px: project name (Sora 700, 14px, letter-spacing 1.5px, white) + "LEARN MORE" pill (10px/700, letter-spacing 2px, 1px border `rgba(255,255,255,.5)`, hover bg→accent/text→`#08141d`).
  - Whole card lifts on hover: `transform: translateY(-6px)`.
  - The three projects, in order:
    1. **SERVICEAGENT** — bg `project-1-serviceagent.png`
    2. **MAILU** — bg `project-2-mailu.png`
    3. **PELO A PELO** — bg `project-3-peloapelo.png`

### 4. About / Quote — id="about"
- **Layout**: padding `100px clamp(20px,6vw,56px)`, solid background `#000409`, flex column, centered, gap 26px.
- **Content**: eyebrow "QUIÉN SOY" (12px/700, letter-spacing 4px, accent) → thin divider (`width:~734px; height:1px; background:rgba(255,255,255,.25)`) → centered quote paragraph (Sora 300, `clamp(19px,2.6vw,22px)`, line-height 1.6, color `#B6ADAD`, max-width 680px): "Soy Vicente Castro, estudiante de Analista Programador y en formación continua en 4Geeks Academy. Desarrollo soluciones full-stack: desde bases de datos y APIs hasta interfaces que la gente disfruta usar. Combino bases técnicas sólidas con aprendizaje constante para construir productos confiables." → second thin divider (`~902px × 1px`, same color).

### 5. Stack + Certifications — id="skills"
- **Layout**: padding `70px clamp(20px,6vw,56px) 90px`, 3-stop gradient `linear-gradient(180deg, #000409, #17273C, #000409)`, flex column, centered, gap 56px. Combined single section, two stacked groups separated by a `146px × 1px` divider (`rgba(255,255,255,.2)`).
- **Group 1 — STACK PRINCIPAL**: eyebrow label (12px/700/letter-spacing 4px/accent) + wrapping row (gap 14px) of pill chips (12px/600, letter-spacing 1.5px, padding 10px 20px, 1px border `rgba(255,255,255,.15)`, `border-radius:20px`, color `rgba(234,242,245,.8)`, hover border+text→accent). Chips, in order: Java, Spring Boot, Next.js / React.js, TypeScript, Tailwind / CSS, AWS, Node.js, PostgreSQL, Docker, Git.
- **Group 2 — CERTIFICACIONES**: same chip style. Chips, in order: Microsoft AZ-900, Microsoft Practitioner (en curso), DevOps Foundation (DFPC), DevOps Essentials (DEPC), Scrum Developer (SDPC), Scrum Foundation (SFPC).

### 6. Footer — id="contact"
- **Layout**: solid background `#000409`, top border `1px solid rgba(255,255,255,.08)`, padding-top 80px. Content grid: `repeat(auto-fit, minmax(180px,1fr))`, gap 44px, max-width 1200px, centered, padding-bottom 56px.
- **Columns**:
  1. Brand: "[VC]" mark (Sora 800, 17px, "VC" in accent color inside plain brackets) + tagline paragraph (13px/1.8, color `rgba(234,242,245,.55)`, max-width 240px): "Desarrollador full-stack construyendo productos web rápidos, escalables y bien diseñados."
  2. **SOBRE MÍ**: Historia (→#about), Educación (→#about), Certificaciones (→#skills).
  3. **SKILLS**: Frontend, Backend, Bases de Datos (placeholder links, href="#").
  4. **PROYECTOS**: Service Agente, Gestión Mailu, Pelo a Pelo, App Móvil (placeholder links, href="#").
  5. **CONTACTO**: email link `mailto:vicentecastroibarra@gmail.com`, phone link `tel:+56956333685` (displayed "+56 9 5633 3685"), location text "Presencial - Remoto - Chile", and 3 circular social icons (32×32px, same style as header language toggles) labeled IN / IG / WA (LinkedIn, Instagram, WhatsApp — placeholder hrefs).
  - All footer link text: 13px, color `rgba(234,242,245,.55)`, hover → accent. Column headings: 12px/700/letter-spacing 2px/white.
- **Bottom bar**: top border `1px solid rgba(255,255,255,.08)`, padding `22px clamp(20px,6vw,56px)`, flex row `justify-content:space-between`, 12px text `rgba(234,242,245,.4)`: "© 2026 Vicente Castro. Todos los derechos reservados." on the left; "Términos de Uso" / "Privacidad" links (href="#") on the right.

## Interactions & Behavior
- Smooth scroll from hero's CTA button and scroll-chevron to the Projects section (scroll to `#projects`, offset -70px to clear the fixed header).
- All buttons/links/chips/cards have a ~0.2–0.3s color/background/border/shadow/transform transition on hover — no click/active states beyond that; no forms, loading states, or validation on this page.
- Fully responsive via `clamp()` for type sizes and `flex-wrap` for the nav, cards, and chip rows — no fixed breakpoints/media queries were used; the layout should reflow fluidly down to mobile widths.

## State Management
None — the page is static content. The only "dynamic" values are the accent color and the card shape (hexagon vs. rounded), which in the original design tool are exposed as two theme toggles rather than user-facing app state:
- `accentColor` (default `#4dd0e1`)
- `cardShape`: `"hexagon"` (default) | `"rounded"` — hexagon uses the clip-path above; rounded drops the clip-path and uses `border-radius:18px` instead.
If the target app doesn't need these as runtime toggles, just hardcode hexagon shape + `#4dd0e1` accent.

## Design Tokens
**Colors**
- Background base: `#0a1520`
- Section backgrounds: `#000000`, `#17273C`, `#000409` (used as 3-stop gradients per section)
- Text primary: `#eaf2f5` / `#ffffff`
- Text muted: `rgba(234,242,245,.4–.85)` (opacity varies by context, see sections above)
- Quote text: `#B6ADAD`
- Accent (cyan): `#4dd0e1`
- Borders: `rgba(255,255,255,.08–.35)`

**Typography**
- Headings/labels: Sora — weights 300, 600, 700, 800
- Body: Inter — weights 400, 500, 600
- Tracked uppercase labels: 10–12px, letter-spacing 1.5–4px
- Hero H1: 34–84px (fluid via clamp)

**Spacing / shape**
- Section vertical padding: 70–150px
- Card size: 252×222px
- Hex clip-path: `polygon(25% 0%,75% 0%,100% 50%,75% 100%,25% 100%,0% 50%)`
- Chip radius: 20px; button radius: 2px; circular icons: 50%

## Assets
- `hero-photo.jpg` — dark mountain/night landscape, hero background (source: user-provided stock photo).
- `project-1-serviceagent.png`, `project-2-mailu.png`, `project-3-peloapelo.png` — real screenshots of the developer's own shipped projects (ServiceAgent, Mailu, Pelo a Pelo), used as project-card backgrounds.
- No icon set — social icons are just 2-letter monogram text (IN/IG/WA/ESP/ENG) in bordered circles, not SVGs.

## Files
- `portfolio-landing.html` — full design reference (all sections above), open directly in a browser to see the live layout/behavior.
